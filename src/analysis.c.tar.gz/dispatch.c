#include "dispatch.h"

#include <pcap.h>
#include <pthread.h>
#include "analysis.h"

struct param_pass {
  struct pcap_pkthdr *headerpass;
  const unsigned char *packetpass;
  int verbosepass;
};

void *thread_code(void *arg) {
  struct param_pass * params = (struct param_pass *) arg;
  analyse(params->headerpass, params->packetpass, params->verbosepass);
  free(arg);
}

void dispatch(struct pcap_pkthdr *header,
              const unsigned char *packet,
              int verbose) {
  // TODO: Your part 2 code here
  // This method should handle dispatching of work to threads. At present
  // it is a simple passthrough as this skeleton is single-threaded.

  struct param_pass * params = malloc(sizeof(struct param_pass));;
  params->headerpass = header;
  params->packetpass = packet;
  params->verbosepass = verbose;
  pthread_t thread;
  pthread_create(&thread, NULL, &thread_code, (void *) params);
  pthread_detach(thread);

  // analyse(header, packet, verbose);
}
